# Mastercard ALM Development Estimate Package

This package contains the revised incremental development estimate for adding the Mastercard ACS/ALM Product Graduation API call to an existing architecture.

Recommended estimate:

- Baseline: 6 MD
- Likely range: 5–8 MD
- Best case with fully reusable Mastercard infrastructure: 3–5 MD

Developer testing is included. Architecture, formal Mastercard certification/MTF, formal QA/UAT and production rollout are excluded.

The previously generated complete Mastercard ALM resource ZIP is also included as a nested reference package.
