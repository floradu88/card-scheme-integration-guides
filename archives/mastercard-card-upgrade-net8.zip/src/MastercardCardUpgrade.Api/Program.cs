using MastercardCardUpgrade.Api.Options;
using MastercardCardUpgrade.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

builder.Services.Configure<MastercardOptions>(
    builder.Configuration.GetSection(MastercardOptions.SectionName));

builder.Services.AddHttpClient<IMastercardBinLookupClient, MastercardBinLookupClient>();
builder.Services.AddHttpClient<IMastercardAlmClient, MastercardAlmClient>();
builder.Services.AddScoped<IMastercardUpgradeService, MastercardUpgradeService>();
builder.Services.AddSingleton<MastercardOAuth1Signer>();

var app = builder.Build();

app.MapGet("/", () => Results.Ok(new
{
    service = "Mastercard Card Upgrade API",
    framework = ".NET 8",
    note = "BIN Lookup is wired to the public Mastercard API. ALM/USS requires issuer-provisioned endpoint/schema."
}));

app.MapControllers();

app.Run();
