namespace MastercardCardUpgrade.Api.Options;

public sealed class MastercardOptions
{
    public const string SectionName = "Mastercard";

    public string ConsumerKey { get; set; } = "";
    public string PrivateKeyPemPath { get; set; } = "";
    public string BinLookupBaseUrl { get; set; } = "https://sandbox.api.mastercard.com";

    // These are intentionally not hard-coded. Obtain the canonical values from
    // Mastercard ALM / Universal Specification Submission onboarding.
    public string AlmSubmissionUrl { get; set; } = "";
    public string AlmStatusUrl { get; set; } = "";
    public string DefaultProductGraduationServiceCode { get; set; } = "";

    public int RequestTimeoutSeconds { get; set; } = 30;
}
