using System.Security.Cryptography;
using System.Text;
using MastercardCardUpgrade.Api.Options;

namespace MastercardCardUpgrade.Api.Services;

/// <summary>
/// Minimal OAuth 1.0a RSA-SHA256 signer suitable for Mastercard-style API calls.
/// Confirm required signing rules against the Mastercard project documentation
/// provisioned for the API you are using.
/// </summary>
public sealed class MastercardOAuth1Signer
{
    public async Task SignAsync(
        HttpRequestMessage request,
        MastercardOptions options,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(options.ConsumerKey))
            throw new InvalidOperationException("Mastercard:ConsumerKey is not configured.");

        if (string.IsNullOrWhiteSpace(options.PrivateKeyPemPath))
            throw new InvalidOperationException("Mastercard:PrivateKeyPemPath is not configured.");

        if (!File.Exists(options.PrivateKeyPemPath))
            throw new FileNotFoundException("Mastercard private key PEM not found.", options.PrivateKeyPemPath);

        var nonce = Guid.NewGuid().ToString("N");
        var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();

        var oauth = new SortedDictionary<string, string>(StringComparer.Ordinal)
        {
            ["oauth_consumer_key"] = options.ConsumerKey,
            ["oauth_nonce"] = nonce,
            ["oauth_signature_method"] = "RSA-SHA256",
            ["oauth_timestamp"] = timestamp,
            ["oauth_version"] = "1.0"
        };

        var queryParameters = ParseQuery(request.RequestUri?.Query);
        foreach (var item in queryParameters)
            oauth[item.Key] = item.Value;

        var normalizedParameters = string.Join("&",
            oauth
                .OrderBy(x => PercentEncode(x.Key), StringComparer.Ordinal)
                .ThenBy(x => PercentEncode(x.Value), StringComparer.Ordinal)
                .Select(x => $"{PercentEncode(x.Key)}={PercentEncode(x.Value)}"));

        var baseUri = request.RequestUri is null
            ? throw new InvalidOperationException("Request URI is required.")
            : $"{request.RequestUri.Scheme}://{request.RequestUri.Authority}{request.RequestUri.AbsolutePath}";

        var signatureBaseString =
            $"{request.Method.Method.ToUpperInvariant()}&{PercentEncode(baseUri)}&{PercentEncode(normalizedParameters)}";

        var pem = await File.ReadAllTextAsync(options.PrivateKeyPemPath, cancellationToken);

        using var rsa = RSA.Create();
        rsa.ImportFromPem(pem);

        var signatureBytes = rsa.SignData(
            Encoding.ASCII.GetBytes(signatureBaseString),
            HashAlgorithmName.SHA256,
            RSASignaturePadding.Pkcs1);

        var signature = Convert.ToBase64String(signatureBytes);

        var authHeaderValues = new Dictionary<string, string>
        {
            ["oauth_consumer_key"] = options.ConsumerKey,
            ["oauth_nonce"] = nonce,
            ["oauth_signature"] = signature,
            ["oauth_signature_method"] = "RSA-SHA256",
            ["oauth_timestamp"] = timestamp,
            ["oauth_version"] = "1.0"
        };

        var authorization = "OAuth " + string.Join(", ",
            authHeaderValues.Select(x =>
                $"{PercentEncode(x.Key)}=\"{PercentEncode(x.Value)}\""));

        request.Headers.TryAddWithoutValidation("Authorization", authorization);
    }

    private static Dictionary<string, string> ParseQuery(string? query)
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        if (string.IsNullOrWhiteSpace(query)) return result;

        foreach (var pair in query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var parts = pair.Split('=', 2);
            var key = Uri.UnescapeDataString(parts[0]);
            var value = parts.Length > 1 ? Uri.UnescapeDataString(parts[1]) : "";
            result[key] = value;
        }
        return result;
    }

    private static string PercentEncode(string value) =>
        Uri.EscapeDataString(value)
            .Replace("!", "%21")
            .Replace("*", "%2A")
            .Replace("'", "%27")
            .Replace("(", "%28")
            .Replace(")", "%29");
}
