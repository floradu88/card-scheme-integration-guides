using System.Net.Http.Json;
using System.Text.Json;
using MastercardCardUpgrade.Api.Models;
using MastercardCardUpgrade.Api.Options;
using Microsoft.Extensions.Options;

namespace MastercardCardUpgrade.Api.Services;

/// <summary>
/// Integration boundary for Mastercard ALM / Universal Specification Submission.
///
/// IMPORTANT:
/// Mastercard's public BIN Lookup Postman collection does not expose the
/// issuer-specific ALM/USS request contract. The request mapping below is
/// deliberately generic and MUST be replaced with the canonical Mastercard
/// OpenAPI/schema obtained during ALM onboarding.
///
/// The orchestration, OAuth signing, error handling, and configuration are
/// already in place so only this mapping should need to change.
/// </summary>
public sealed class MastercardAlmClient : IMastercardAlmClient
{
    private readonly HttpClient _http;
    private readonly MastercardOptions _options;
    private readonly MastercardOAuth1Signer _signer;

    public MastercardAlmClient(
        HttpClient http,
        IOptions<MastercardOptions> options,
        MastercardOAuth1Signer signer)
    {
        _http = http;
        _options = options.Value;
        _signer = signer;
        _http.Timeout = TimeSpan.FromSeconds(_options.RequestTimeoutSeconds);
    }

    public async Task<AlmSubmissionResult> SubmitProductGraduationAsync(
        AlmSubmission submission,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_options.AlmSubmissionUrl))
            throw new InvalidOperationException(
                "Mastercard:AlmSubmissionUrl is not configured. Obtain the exact USS endpoint from Mastercard ALM onboarding.");

        // TODO(MASTERCARD-ALM):
        // Replace this anonymous object with generated DTOs from the official
        // Universal Specification Submission OpenAPI/schema.
        //
        // These names are intentionally generic application-level names and
        // are NOT asserted to be Mastercard's canonical wire field names.
        var payload = new
        {
            pan = submission.Pan,
            targetProductCode = submission.TargetProductCode,
            ica = submission.Ica,
            effectiveDate = submission.EffectiveDate.ToString("yyyy-MM-dd"),
            serviceCode = submission.ServiceCode,
            correlationId = submission.CorrelationId
        };

        using var request = new HttpRequestMessage(HttpMethod.Post, _options.AlmSubmissionUrl)
        {
            Content = JsonContent.Create(payload)
        };
        request.Headers.Accept.ParseAdd("application/json");
        request.Headers.TryAddWithoutValidation("X-Correlation-Id", submission.CorrelationId);

        await _signer.SignAsync(request, _options, cancellationToken);

        using var response = await _http.SendAsync(request, cancellationToken);
        var raw = await response.Content.ReadAsStringAsync(cancellationToken);

        object? parsed = TryParseJson(raw);

        if (!response.IsSuccessStatusCode)
            return new AlmSubmissionResult(
                false,
                null,
                $"HTTP_{(int)response.StatusCode}",
                parsed ?? raw);

        // TODO(MASTERCARD-ALM):
        // Map Mastercard's canonical submission/reference/status fields here.
        var reference = response.Headers.TryGetValues("Location", out var location)
            ? location.FirstOrDefault()
            : null;

        return new AlmSubmissionResult(
            true,
            reference,
            "SUBMITTED",
            parsed ?? raw);
    }

    public async Task<AlmStatusResult> GetStatusAsync(
        string mastercardReference,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_options.AlmStatusUrl))
            throw new InvalidOperationException(
                "Mastercard:AlmStatusUrl is not configured. Obtain the exact Detailed Response/status endpoint from Mastercard ALM onboarding.");

        var url = _options.AlmStatusUrl.Replace(
            "{reference}",
            Uri.EscapeDataString(mastercardReference),
            StringComparison.OrdinalIgnoreCase);

        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        request.Headers.Accept.ParseAdd("application/json");

        await _signer.SignAsync(request, _options, cancellationToken);

        using var response = await _http.SendAsync(request, cancellationToken);
        var raw = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException(
                $"Mastercard ALM status failed: {(int)response.StatusCode} {response.ReasonPhrase}. Body: {raw}");

        // TODO(MASTERCARD-ALM): map canonical response status.
        return new AlmStatusResult("RECEIVED", TryParseJson(raw) ?? raw);
    }

    private static object? TryParseJson(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;
        try { return JsonSerializer.Deserialize<JsonElement>(raw); }
        catch { return null; }
    }
}
