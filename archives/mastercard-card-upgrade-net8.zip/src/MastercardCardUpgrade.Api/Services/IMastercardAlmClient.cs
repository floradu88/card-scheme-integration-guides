using MastercardCardUpgrade.Api.Models;

namespace MastercardCardUpgrade.Api.Services;

public interface IMastercardAlmClient
{
    Task<AlmSubmissionResult> SubmitProductGraduationAsync(
        AlmSubmission submission,
        CancellationToken cancellationToken = default);

    Task<AlmStatusResult> GetStatusAsync(
        string mastercardReference,
        CancellationToken cancellationToken = default);
}
