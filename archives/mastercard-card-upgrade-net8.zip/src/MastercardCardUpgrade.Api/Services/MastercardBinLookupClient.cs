using System.Net.Http.Json;
using MastercardCardUpgrade.Api.Models;
using MastercardCardUpgrade.Api.Options;
using Microsoft.Extensions.Options;

namespace MastercardCardUpgrade.Api.Services;

public sealed class MastercardBinLookupClient : IMastercardBinLookupClient
{
    private readonly HttpClient _http;
    private readonly MastercardOptions _options;
    private readonly MastercardOAuth1Signer _signer;

    public MastercardBinLookupClient(
        HttpClient http,
        IOptions<MastercardOptions> options,
        MastercardOAuth1Signer signer)
    {
        _http = http;
        _options = options.Value;
        _signer = signer;
        _http.Timeout = TimeSpan.FromSeconds(_options.RequestTimeoutSeconds);
    }

    public async Task<BinAccountRangeResponse> SearchAccountRangeAsync(
        string panOrAccountRange,
        CancellationToken cancellationToken = default)
    {
        var digits = new string(panOrAccountRange.Where(char.IsDigit).ToArray());
        if (digits.Length < 6)
            throw new ArgumentException("At least 6 digits are required.");

        // Mastercard public Postman docs state 6-8 digit BINs or up to
        // the 11th digit of an account range.
        var lookupDigits = digits[..Math.Min(11, digits.Length)];
        if (!long.TryParse(lookupDigits, out var accountRange))
            throw new ArgumentException("The account range is invalid.");

        var url = $"{_options.BinLookupBaseUrl.TrimEnd('/')}/bin-ranges/account-searches";
        var payload = new AccountRangeSearchRequest(accountRange);

        using var request = new HttpRequestMessage(HttpMethod.Post, url)
        {
            Content = JsonContent.Create(payload)
        };
        request.Headers.Accept.ParseAdd("application/json");

        await _signer.SignAsync(request, _options, cancellationToken);

        using var response = await _http.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException(
                $"Mastercard BIN Lookup failed: {(int)response.StatusCode} {response.ReasonPhrase}. Body: {body}");

        var result = System.Text.Json.JsonSerializer.Deserialize<BinAccountRangeResponse>(
            body,
            new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        return result ?? throw new InvalidOperationException("Mastercard returned an empty BIN Lookup response.");
    }
}
