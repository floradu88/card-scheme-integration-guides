using MastercardCardUpgrade.Api.Models;
using MastercardCardUpgrade.Api.Options;
using Microsoft.Extensions.Options;

namespace MastercardCardUpgrade.Api.Services;

public sealed class MastercardUpgradeService : IMastercardUpgradeService
{
    private readonly IMastercardBinLookupClient _binLookup;
    private readonly IMastercardAlmClient _alm;
    private readonly MastercardOptions _options;

    public MastercardUpgradeService(
        IMastercardBinLookupClient binLookup,
        IMastercardAlmClient alm,
        IOptions<MastercardOptions> options)
    {
        _binLookup = binLookup;
        _alm = alm;
        _options = options.Value;
    }

    public async Task<CardUpgradeResult> UpgradeAsync(
        CardUpgradeRequest request,
        CancellationToken cancellationToken = default)
    {
        var pan = NormalizePan(request.Pan);
        ValidatePan(pan);

        var correlationId = request.CorrelationId ?? Guid.NewGuid().ToString("N");

        // Step 1: Public Mastercard BIN/account-range lookup.
        var current = await _binLookup.SearchAccountRangeAsync(pan, cancellationToken);

        if (string.Equals(current.ProductCode, request.TargetProductCode, StringComparison.OrdinalIgnoreCase))
        {
            return new CardUpgradeResult(
                correlationId,
                MaskPan(pan),
                current.ProductCode,
                current.ProductDescription,
                current.Ica,
                request.TargetProductCode,
                "NO_CHANGE_ALREADY_TARGET_PRODUCT",
                null,
                null);
        }

        // Step 2: Submit PAN-level Product Graduation / ALM event.
        var submission = new AlmSubmission(
            Pan: pan,
            TargetProductCode: request.TargetProductCode,
            Ica: current.Ica,
            EffectiveDate: request.EffectiveDate ?? DateOnly.FromDateTime(DateTime.UtcNow),
            ServiceCode: request.ServiceCode ?? _options.DefaultProductGraduationServiceCode,
            CorrelationId: correlationId);

        var result = await _alm.SubmitProductGraduationAsync(submission, cancellationToken);

        return new CardUpgradeResult(
            correlationId,
            MaskPan(pan),
            current.ProductCode,
            current.ProductDescription,
            current.Ica,
            request.TargetProductCode,
            result.Status,
            result.MastercardReference,
            result.RawResponse);
    }

    private static string NormalizePan(string pan) =>
        new(pan.Where(char.IsDigit).ToArray());

    private static void ValidatePan(string pan)
    {
        if (pan.Length < 12 || pan.Length > 19)
            throw new ArgumentException("PAN must contain 12 to 19 digits.");

        // Luhn is intentionally not enforced here because test PANs / account
        // ranges can vary by environment. Add it if required by your issuer flow.
    }

    private static string MaskPan(string pan) =>
        pan.Length <= 10
            ? new string('*', pan.Length)
            : $"{pan[..6]}{new string('*', pan.Length - 10)}{pan[^4..]}";
}
