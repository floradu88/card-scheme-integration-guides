using MastercardCardUpgrade.Api.Models;
using MastercardCardUpgrade.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace MastercardCardUpgrade.Api.Controllers;

[ApiController]
[Route("api/mastercard")]
public sealed class MastercardController : ControllerBase
{
    [HttpPost("bin-lookup")]
    public async Task<ActionResult<BinAccountRangeResponse>> BinLookup(
        [FromBody] BinLookupApiRequest request,
        [FromServices] IMastercardBinLookupClient client,
        CancellationToken cancellationToken)
    {
        var result = await client.SearchAccountRangeAsync(
            request.PanOrAccountRange,
            cancellationToken);

        return Ok(result);
    }

    [HttpPost("upgrade")]
    public async Task<ActionResult<CardUpgradeResult>> Upgrade(
        [FromBody] CardUpgradeRequest request,
        [FromServices] IMastercardUpgradeService service,
        CancellationToken cancellationToken)
    {
        var result = await service.UpgradeAsync(request, cancellationToken);
        return Ok(result);
    }

    [HttpGet("alm/status/{reference}")]
    public async Task<ActionResult<AlmStatusResult>> Status(
        string reference,
        [FromServices] IMastercardAlmClient client,
        CancellationToken cancellationToken)
    {
        var result = await client.GetStatusAsync(reference, cancellationToken);
        return Ok(result);
    }
}

public sealed record BinLookupApiRequest(string PanOrAccountRange);
