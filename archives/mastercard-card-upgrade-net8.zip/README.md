# Mastercard Card Product Upgrade – .NET 8 sample

Single-solution / single-project sample showing the architecture for upgrading
an individual Mastercard card using:

1. Mastercard BIN Lookup
2. ALM / Product Graduation
3. Universal Specification Submission
4. Detailed Response / status verification

## Important boundary

The Mastercard BIN Lookup API is publicly documented in Mastercard's Postman
workspace.

The canonical ALM / Universal Specification Submission request/response contract
was not publicly exposed in the BIN Lookup collection used as the starting point.
Therefore this sample **does not invent Mastercard wire-level field names**.

`MastercardAlmClient.cs` is the integration boundary. Once Mastercard supplies the
ALM/USS OpenAPI/schema and issuer-specific URLs, replace only the generic payload
mapping and response mapping there.

## Structure

- `MastercardCardUpgrade.sln`
- one ASP.NET Core 8 project:
  - `src/MastercardCardUpgrade.Api`
- `docs/`
- `postman/`

## Flow

```text
PAN
 |
 v
BIN/account-range lookup
 |
 +--> native product
 +--> ICA
 +--> program/account-range data
 |
 v
eligibility validation
 |
 v
ALM / Product Graduation
 |
 v
Universal Specification Submission
 |
 v
Mastercard processing
 |
 v
Detailed Response / status
 |
 +--> accepted -> upgraded
 +--> rejected -> remediation/retry
```

## Configuration

Populate:

```json
{
  "Mastercard": {
    "ConsumerKey": "...",
    "PrivateKeyPemPath": "/secure/path/mastercard-private-key.pem",
    "BinLookupBaseUrl": "https://sandbox.api.mastercard.com",
    "AlmSubmissionUrl": "ISSUER_PROVISIONED_URL",
    "AlmStatusUrl": "ISSUER_PROVISIONED_URL_WITH_{reference}",
    "DefaultProductGraduationServiceCode": "ISSUER_PROVISIONED_CODE"
  }
}
```

Never commit Mastercard keys, PAN data, secrets or production credentials.

## Run

```bash
dotnet restore
dotnet run --project src/MastercardCardUpgrade.Api
```

Then use `MastercardCardUpgrade.Api.http` or the supplied Postman collection.

## Note about build verification

This package was generated in an environment where the `dotnet` CLI was not
available, so it could not be compiled in-session. The code is structured for
.NET 8 and uses only framework libraries.
