# Add-on: Generic Dynamic Interchange Requirements

This package extends the previous Payment Platform v3 handbook.

Purpose:
- Convert a business initiative into vendor-neutral requirements.
- Add functional requirements, architecture implications and implementation checklists.
- Can be merged into Phase 1, 2 and 3 documentation.
