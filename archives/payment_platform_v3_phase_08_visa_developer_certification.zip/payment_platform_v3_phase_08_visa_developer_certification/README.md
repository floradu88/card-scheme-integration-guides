# Phase 08 — Visa Developer Tooling, Implementation & Certification Pack

Vendor-specific add-on to the generic payment platform handbook.

Scope:
- Visa Developer tooling and project resources
- .NET implementation work breakdown
- Sandbox → Onboarding → Certification → Production
- 12-week planning calendar (template; actual Visa duration is product/project dependent)
- certification evidence checklist
- communication plan and email templates
- official source registry

Important: Visa states onboarding may range from about two weeks to multiple months depending on readiness and product complexity. The calendar here is therefore a planning baseline, not a Visa commitment.
