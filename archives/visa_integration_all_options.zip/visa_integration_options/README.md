# Visa Integration Options

- **Option A — Authorization-Only Proof of Concept** — `A-authorization-only-poc.zip`
- **Option B — Authorization, Capture, and Clearing** — `B-authorization-capture-clearing.zip`
- **Option C — Full Visa Payment-Processing Integration** — `C-full-payment-processing.zip`
- **Option D — Interchange Estimation Only** — `D-interchange-estimation-only.zip`
- **Option E — Clearing Reconciliation Only** — `E-clearing-reconciliation-only.zip`
- **Option F — Replace an Existing Visa Processor Connection** — `F-processor-connection-replacement.zip`
