# Payment Platform Architecture Handbook v3 — Master Index

Generated: 2026-07-29

Download and use the six phase ZIPs in order:

1. Foundation
2. Network Integration
3. Security and Compliance
4. Platform Engineering
5. Operations
6. Engineering Assets

Each phase has its own stage gate and readiness criteria.
