# Phase 04 — Platform Engineering
Kubernetes, Terraform, CI/CD, observability, capacity, and FinOps.
